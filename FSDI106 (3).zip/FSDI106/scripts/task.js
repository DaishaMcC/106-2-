class task {

    constructor(title,description,color,date,status,budget)
    {
        this.title = title;
        this.description = description;
        this.color = color;
        this.date = date;
        this.status = status;
        this.budget = budget;
        this.name = "Daisha";
    }
}